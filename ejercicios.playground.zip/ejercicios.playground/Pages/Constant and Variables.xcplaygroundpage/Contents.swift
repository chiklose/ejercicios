import UIKit

//Constants and Variables
//Find the error

var constant: Int = 10
var y: Int = 10
var x: Int = y + constant
constant = x
y = x * constant
