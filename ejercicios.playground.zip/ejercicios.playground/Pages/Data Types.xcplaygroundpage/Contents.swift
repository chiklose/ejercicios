//: [Previous](@previous)

import Foundation


//Data Types

var welcomeMessage: String = "Welcome"
var isEnabled: Bool = true
let pi: Double = 3.1416
let area: Int = 13
var fistVar: String
var secondVar: Bool
var thirdVar: String
secondVar = false
