//: [Previous](@previous)

import Foundation

//Operadores
//Complete the missing operators

let celsius: Double = 100
let fahrenheit: Double = (celsius * (9 / 5)) + 32
// is equal to 212 (use celsius to fahrenheit formula)

var a = 46
a += 28 // 74

if 5 * 3 > 10 && 5 + 6 >= 11 {
    print(true)
}else {
    print(false)
}
// is true
