//: [Previous](@previous)

import Foundation

//Tuple

let tuple = (title: "Master of Puppets", artist: "Metallica", gender: "M", time: 1986)

print(tuple.time)

